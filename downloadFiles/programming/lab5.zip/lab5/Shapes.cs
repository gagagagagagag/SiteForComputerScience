﻿using System;
namespace ENG_Lab05
{
    public abstract class Shape
    {
    }

    public class Point
    {
        public double X;
        public double Y;
    }

}
