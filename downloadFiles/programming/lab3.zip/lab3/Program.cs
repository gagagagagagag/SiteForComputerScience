﻿using System;

namespace ENG_Lab04
{
    class Program
    {
        /*
            0.0 Look At Given Structure And Class Definition.
                Study How Values Change During Program Execution Depending On A Value/Reference Type.
        */
        private struct PointStruct
        {
            public int X;
            public int Y;

            public PointStruct(int _x, int _y)
            {
                this.X = _x;
                this.Y = _y;
            }

            public override string ToString()
            {
                return $"X: {X}, Y: {Y}";
            }
        }

        private class PointClass
        {
            public int X = 0;
            public int Y = 5;

            public PointClass(int _x, int _y)
            {
                this.X = _x;
                this.Y = _y;
            }

            public override string ToString()
            {
                return $"X: {X}, Y: {Y}";
            }
        }

        static void Main(string[] args)
        {
            /*
                0.1 Look At Given Structure And Class Definition.
                    Study How Values Change During Program Execution Depending On A Value/Reference Type.
            */
            PointStruct pointStruct_1 = new PointStruct(1, 5);

            PointClass pointClass_1 = new PointClass(1, 5);

            PointStruct pointStruct_2 = pointStruct_1;
            PointClass pointClass_2 = pointClass_1;

            Console.WriteLine($"MyStruct Instance #1: Field_1({pointStruct_1.X}) And Field_2({pointStruct_1.Y})");
            Console.WriteLine($"MyStruct Instance #2: Field_1({pointStruct_2.X}) And Field_2({pointStruct_2.Y})");

            pointStruct_2.X = 25;
            pointStruct_2.Y = 10;

            Console.WriteLine($"MyStruct Instance #1: Field_1({pointStruct_1.X}) And Field_2({pointStruct_1.Y})");
            Console.WriteLine($"MyStruct Instance #2: Field_1({pointStruct_2.X}) And Field_2({pointStruct_2.Y})");

            Console.WriteLine();

            Console.WriteLine($"MyClass Instance #1: Field_1({pointClass_1.X}) And Field_2({pointClass_1.Y})");
            Console.WriteLine($"MyClass Instance #2: Field_1({pointClass_2.X}) And Field_2({pointClass_2.Y})");

            pointClass_2.X = 25;
            pointClass_2.Y = 10;

            Console.WriteLine($"MyClass Instance #1: Field_1({pointClass_1.X}) And Field_2({pointClass_1.Y})");
            Console.WriteLine($"MyClass Instance #2: Field_1({pointClass_2.X}) And Field_2({pointClass_2.Y})");

            Console.WriteLine("\nPets Creation - Constructors:");

            /*
                3.0 Create An Array Of Different Pets That Contains Both Dogs And Cats.
                    Use Array Initialization List.
            */



            /*
                4.0 Iterate Through An Array And Print All Pets.
            */
            Console.WriteLine("\nMethod ToString:");


            Console.WriteLine();
            /*
                5.0 Create Several Variants Of Arrays:
                    - Two-Dimentional Array Of PointStruct (Initialize With i,k Values).
                    - One-Dimentional Array Of One-Dimentional Arrays Of PointStruct (Initialize With i,k Values).
            */


            /*
                5.1 Create Several Variants Of Arrays (Take A Look At Differences Between Reference And Value Types):
                    - One-Dimentional Arraf Of PointStruct. Print Each Element In Format 'X:{X},Y:{Y}'.
                    - One-Dimentional Arraf Of PointClass. Print Each Element In Format 'X:{X},Y:{Y}'.
                    Note That When Using NotInitialized Values With PointClass An Exception Is Thrown.
            */
            /*
                5.2 Initialize Each Element With Some Values And See What Happens.
            */

            PointStruct[] structArr = new PointStruct[5];
            PointClass[] classArr = new PointClass[5];

            for (int i = 0; i < structArr.Length; i++)
                Console.WriteLine(structArr[i]);

            Console.WriteLine();

            for (int i = 0; i < classArr.Length; i++)
                Console.WriteLine(classArr[i]);

            Console.WriteLine();
            for (int i = 0; i < structArr.Length; i++)
                structArr[i] = new PointStruct(i, i);

            for (int i = 0; i < classArr.Length; i++)
                classArr[i] = new PointClass(i,i);

            for (int i = 0; i < structArr.Length; i++)
                Console.WriteLine(structArr[i]);

            Console.WriteLine();

            for (int i = 0; i < classArr.Length; i++)
                Console.WriteLine(classArr[i]);

            Console.WriteLine();

            /*
                6.1 Call 'Get' Method And See What Happens.
            */
            float outArgumentValue = 0.0f;
            Console.WriteLine($"Out Argument Value Before Method: {outArgumentValue}");


            Console.WriteLine($"Out Argument Value After Method: {outArgumentValue}");
            /*
                7.1 Call 'Addition' Method And See What Happens.
                    Print Output To The Screen "Reference In Action: 'Value'".
            */
            int aValue = 5;
            int bValue = 10;
            Console.WriteLine($"\nArguments Before Method: aValue({aValue}) And bValue({bValue})");


            Console.WriteLine($"Arguments After Method: aValue({aValue}) And bValue({bValue})");
            /*
                8.1 Call 'Multiplication' Method Using Named Arguments.
                    Make Use Of Default Values Defined For Arguments. Call Method Providing Only Second Argument.
                    Print Output To The Screen "Named Arguments In Action: 'Value'".
            */


            /*
                9.1 Call (At Least Two Times) 'Addition' Method Providing Various Number Of Arguments.
                    Print Output To The Screen "N-th Use Of Params: 'Value'".
            */
            Console.WriteLine("\nParams Arguments In Action:");


        }

        /*
            6.0 Implement 'Get' Method That Sets Out Arguments Value.
        */


        /*
            7.0 Implement 'Addition' Method That Adds Two Int Values.
                Second Argument Should Be Passed By Reference.
                Modify Both Arguments Before Addition And Return.
        */


        /*
            8.0 Implement 'Multiplication' Method That Multiplies Int Value By Float Value And Can Be Called From Main Method.
                Assign Both Arguments With Default Values.
        */


        /*
            9.0 Implement 'Addition' Method That Adds Given Float Values.
                Use Params Keyword To Take Variable Number Of Arguemnts.
        */


    }
}
