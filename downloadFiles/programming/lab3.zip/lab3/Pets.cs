﻿using System;

namespace ENG_Lab04
{
    /*
        1.0 Create Public Abstract Class 'Pet' Which Contains:
            - Private Static 'Counter' Field Of Type Unsigned Int.
            - Accessible To Derived Classes 'Number' Field Of Type Unsigned Int Which Is Readonly.
            - Accessible To Derived Classes 'Name' Field Of Type String Which Is Readonly.
            - Accessible To Derived Classes 'Age' Field Of Type Unsigned Int.
        Constructor (Public):
            - Should Accept 'Name' And 'Age' Of Pet.
                Sets Appropriately All Fields And Increments 'Counter'.
                Prints "New Pet With Name 'Name' At Age 'Age' With Number 'Number'"Using String Interpolation.
        Methods:
            - Public 'Speak' Method That Accepts No Parameters And Returns Nothing.
                Make This One An Abstract Method.
    */


    /*
        2.0 Create Two Public Classes (Dog And Cat) That Derived From Abstract Pet Class And Contains:
            - Private Static 'Counter' Field Of Type Unsigned Int,
            - Private 'Number' Field Of Type Unsigned Int Which Is Readonly.
                Make Sure To Hide Base Class 'Number' Properly (No Warnings At This Stage Should Be Visible).
            Note That There Is No Need To Hide 'Counter' Field. That Is Because It Has Private Modifier In Base Class And Is Not Accessible To Derived Class.
        Constructor (Public):
            - Should Accept Any Field That Have To Be Forwarded To Base Class.
                Calls Appropriately Base Class Constructor.
                Sets Appropriately All Fields And Increments 'Counter'.
                For Dog Prints "New Dog With Name 'Name' At Age 'Age' With Number 'Number'" Using String Interpolation.
                For Cat Prints "New Cat With Name 'Name' At Age 'Age' With Number 'Number'" Using String Interpolation.
        Methods:
            - Public 'Speak' Method That Overrides Pet's Class Method.
                For Dog It Should Print "Dog 'Name' Speaks: Woof, Woof!". Use String Interpolation.
                For Cat It Should Print "Cat 'Name' Demands: Meow, Meow!". Use String Interpolation.
            - Public Class Own Method.
                For Dog Void 'Fetch' Method With No Parameters Which Prints "Dog 'Name' Is Fetching A Stick!". Use String Interpolation.
                For Cat Implement Your Own Method That Also Prints Something To The Screen.
    */
    /*
        4.1 Implement Public 'ToString' Method Which Overrides Original Method.
            - For Dog Prints "Dog 'Name' ('Number') - Pet Number 'Number' Is 'Age' Years Old!". Remember To Call Fields Appropriately. Use String Interpolation.
            - For Cat Prints "Cat 'Name' ('Number') - Pet Number 'Number' Is 'Age' Years Old!". Remember To Call Fields Appropriately. Use String Interpolation.
        Note That There Is Different Output With And Without 'ToString' Method Implemented.
    */


}
