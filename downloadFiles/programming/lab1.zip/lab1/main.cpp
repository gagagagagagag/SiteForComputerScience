#include "pets.hpp"

// 8.
// Here it's definitely mistake (and these happen all the time), but in real project it may happen
// that file you include was already included by other file. Without  include guards (or #pragma once, but
// it may be not supported by some compilers - especially proprietary compilers for embedded platforms)
// file would be included twice what would result in your classes being defined twice.
// 
//#include "pets.hpp"

#include <memory>
#include <vector>
#include <algorithm>
#include <numeric>
#include <cctype>

int main() {

	std::cout << "Start of main" << std::endl << std::endl;

	// 3. Create 3+ different pets of at leas two types and put them in vector pets.

	std::cout << "\nPets from collection:" << std::endl;

	std::vector<Pet*> pets;

	for (Pet* pet : pets) {
		std::cout << pet << std::endl;
	}

	std::cout << "\nEnd of collection" << std::endl;

	// 5. Using STL algorithm (accumulate) count sum and average age of pets collection.

    // To do


	// 6. Sort pets by age (and list sorted)  

    // To do


    // 7. Free memory before leaving main

    // To do



	std::cout << "\nEnd of main================================\n" << std::endl;
	
	
}

