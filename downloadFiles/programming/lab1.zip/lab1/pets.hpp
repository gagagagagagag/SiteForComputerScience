// 8. Create include guards

#include <string>
#include <iostream>

// 1. Create abstract class Pet that have:
//     - name (string)
//     - age (unsigned int)
//     - number (unique, assigned at object creation, protected field)
//     - whatever you feel is necessary
//    Methods:
//     - Speak (abstract method, returns void, no parameters, const).
//     - PrintDescription (abstract method) - see operator<< below. Should have one std::ostream& parameter.
//     - Age - just returns pets age.
//     - AddAge - increases age of pet by given amount.
//    Constructors:
//     - One constructor accepting pets name and age. It should print on console: "New pet with name ABC at age X with number Y"
//    Destructor:
//     - Prints "Pet number X disappears."
//    Operators:
//     - operator<< - should use virtual method Description.


// 2. Define few (2 or 3) classes derived publicly from Pet.
//    Each class should have:
//     - number (value unique in objects of this class)
//    define constructor:
//     - accepting any fields that have to be forwarded to base class constructor. It should print "Wild race name appears" (e.g. "Wild cat Theo appears").
//    and override Speak and Description methods.
//     - Example Description: "Cat Ferdinand (pet number 4, cat number 2) is 3 years old"
//     - Example Speak: "Cat Ferdinand demands: meow, meow"
//    Additionally ONE derived class should have it's own unique method.
//    E.g. it may be class Dog with method Fetch that will print on cosole "Dog Titus is fetching stick".

