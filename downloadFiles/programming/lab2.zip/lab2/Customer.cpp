#include "Customer.h"
#include "Store.h"

namespace Lab02
{
    std::ostream& operator<<(std::ostream& out, const Customer& customer)
    {
        for (const std::pair<int, int>& orderItem : customer.shoppingList)
        {
            out << "ProductID: " << std::setw(2) << orderItem.first << " With Quantity: " << orderItem.second << std::endl;
        }

        return out;
    }

    /* Implement Methods Here */

	

}
