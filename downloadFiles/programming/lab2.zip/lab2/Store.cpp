#include "Store.h"
#include "Customer.h"

namespace Lab02
{

    /* Already Implemented */
    std::ostream& operator<<(std::ostream& out, const Store& store)
    {
        for (const StoreProduct& storeItem : store.productsInStore)
        {
            out << "Product: " << std::setw(10) << storeItem.productName << " (" << std::setw(2) << storeItem.productID << ") With Price: " << std::setw(6) << storeItem.productPrice << " And Quantity: " << storeItem.productQuantity << std::endl;
        }

        return out;
    }

    /* Already Implemented */
    void Store::RefillTheStore(std::map<int, int> newProducts)
    {
        std::for_each(newProducts.cbegin(), newProducts.cend(), [&](const std::pair<int, int>& productToQuantity)
        {
            auto itemFound = std::find_if(this->productsInStore.begin(), this->productsInStore.end(), [=](const StoreProduct& storeProduct)
            {
                return storeProduct.productID == productToQuantity.first;
            });

            if (itemFound != this->productsInStore.end())
            {
                itemFound->productQuantity = productToQuantity.second;
            }
            else
            {
                this->productsInStore.push_back(StoreProduct(productToQuantity.first, productToQuantity.second, 10.0, "NewProduct_" + std::to_string(productToQuantity.first)));
            }
        });
    }

    /* Implement Methods Here */

	

}
